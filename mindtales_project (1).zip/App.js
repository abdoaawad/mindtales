import React from 'react';
import './App.css';

function App() {
  return (
    <div className="App">
      <h1>Welcome to Mindtales</h1>
      <p>Your go-to place for books, stories, and personal experiences.</p>
    </div>
  );
}

export default App;