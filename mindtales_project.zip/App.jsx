
import React from 'react';

function App() {
  return (
    <div>
      <h1>Welcome to Mindtales</h1>
      <p>Your go-to place for books, stories, and personal experiences.</p>
    </div>
  );
}

export default App;
